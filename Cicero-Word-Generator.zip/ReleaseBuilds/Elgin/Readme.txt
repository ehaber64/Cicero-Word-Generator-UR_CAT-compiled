This is Elgin Run Log Explorer, part of the Cicero Word Generator control software suite for atomic physics experiments.

For more information, see http://akeshet.github.com/Cicero-Word-Generator/