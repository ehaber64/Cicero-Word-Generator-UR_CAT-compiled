This is Cicero Word Generator client, part of the Cicero Word Generator control software suite for atomic physics experiments.

For more information, see http://akeshet.github.com/Cicero-Word-Generator/