This is the compiled distribution of the Cicero Word Generator Suite. For the source code, and further information, see http://akeshet.github.com/Cicero-Word-Generator/

The Cicero Word Generator Suite is distributed under the GNU Public License. For further information, see http://akeshet.github.com/Cicero-Word-Generator/